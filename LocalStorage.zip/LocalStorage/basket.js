let table=document.getElementById("table")
let totalPrice=document.getElementById("totalPrice")
let totalProductPrice=0;

function GetBasketCount(){
    if(JSON.parse(localStorage.getItem("basket"))!==null){
        let basket=JSON.parse(localStorage.getItem("basket"));
        basketCount.innerText=basket.length;
    }
    
}
GetBasketCount();
if(JSON.parse(localStorage.getItem("basket"))!==null){
    let basket=JSON.parse(localStorage.getItem("basket"));
    basket.forEach(product => {
        totalProductPrice+=product.count*product.price
        let tr=document.createElement("tr");
        let tdImage=document.createElement("td");
        let img=document.createElement("img");
        img.setAttribute("src",product.imageUrl);
        img.style.width="100px";
        tdImage.appendChild(img);
        
        let tdProductName=document.createElement("td");
        tdProductName.innerText=product.name;
    
        let tdProductPrice=document.createElement("td");
        tdProductPrice.innerText=product.price+"$";
    
        let tdProductCount=document.createElement("td");
        tdProductCount.innerText=product.count;
        
        tr.append(tdImage,tdProductName,tdProductPrice,tdProductCount);
        table.lastElementChild.appendChild(tr);
        
    });
    
}

totalPrice.innerText=totalProductPrice

if(JSON.parse(localStorage.getItem("basket")==null)){

        table.style.display="none";
        document.getElementById("home").style.display="block"
      
}
