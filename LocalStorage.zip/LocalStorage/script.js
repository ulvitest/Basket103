// let num =5;
//  localStorage.setItem("num",num);
//  localStorage.setItem("name","Ibo");
//  localStorage.removeItem("name");
//  localStorage.clear();
// sessionStorage.setItem("num2",100);
// console.log(sessionStorage.getItem("num2"));
//document.cookie="userName=Nergiz;expires=Fri May 13 2022 09:06:30 GMT+0400;"
// localStorage.setItem("arr",JSON.stringify([1,2,3]))
// console.log(JSON.parse(localStorage.getItem("arr")));

let allBtn=document.querySelectorAll(".btn");
let basketCount=document.getElementById("basketCount");
if(localStorage.getItem("basket")==null){
    localStorage.setItem("basket",JSON.stringify([]));
}

allBtn.forEach(btn=>{
    btn.onclick=function(){
        if(localStorage.getItem("basket")==null){
            localStorage.setItem("basket",JSON.stringify([]));
        }
      let basket= JSON.parse(localStorage.getItem("basket"));

       let existProduct=basket.find(product=>product.id==btn.parentElement.parentElement.getAttribute("data-id"));
       console.log(existProduct);
       if(existProduct===undefined){
           basket.push({
               id:btn.parentElement.parentElement.getAttribute("data-id"),
               name:btn.parentElement.firstElementChild.innerText,
               count:1,
               price:btn.previousElementSibling.previousElementSibling.innerText,
               imageUrl:btn.parentElement.previousElementSibling.getAttribute("src")
           })
       }
       else{
           existProduct.count++;
       }
       localStorage.setItem("basket",JSON.stringify(basket))
       GetBasketCount();

    }
})

function GetBasketCount(){
    let basket=JSON.parse(localStorage.getItem("basket"));
    basketCount.innerText=basket.length;
}
GetBasketCount();